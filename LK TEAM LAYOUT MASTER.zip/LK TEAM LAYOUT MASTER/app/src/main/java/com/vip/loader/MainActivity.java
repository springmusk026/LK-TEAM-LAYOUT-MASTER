package com.vip.loader;
 
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;

public class MainActivity extends Activity { 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
			startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 2002);
		}else{

			this.startService(new Intent(this, Loader.class));


		}
		
    }
}

