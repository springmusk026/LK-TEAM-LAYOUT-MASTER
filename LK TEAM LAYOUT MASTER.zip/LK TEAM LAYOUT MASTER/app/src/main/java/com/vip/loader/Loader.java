package com.vip.loader;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.vip.loader.Loader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.json.JSONObject;
import android.os.IBinder;
import android.content.Intent;

public class Loader<packageInfoList> extends Service {
    /* access modifiers changed from: private */
    
	private final  String SERVERURL(){
		
		return "https://muskmods.club/vin.php";
	}
	
	
	
	public static boolean isRunning = false;
    public static SharedPreferences.Editor mEditor;
    private static SharedPreferences mPreferences;
    private GradientDrawable BackgroundBanner;
    private GradientDrawable BackgroundFechar;
    private GradientDrawable BackgroundPrincipal;
    private Button ButtonFechar;
    private ImageView ImagemBanner;
    private ImageView ImagemLogo;
    private LinearLayout LayoutBanner;
    private LinearLayout LayoutClose;
    private LinearLayout LayoutFuncs;
    /* access modifiers changed from: private */
    public LinearLayout LayoutPrincipal;
    private String PASS = "PASS";
    /* access modifiers changed from: private */
    public RelativeLayout RelativeCollapsed;
    private RelativeLayout RelativeContainer;
    private ScrollView ScrollFuncs;
    private String USER = "USER";
    private String Versao = "Lite";
    private WebView WebCreditos;
    /* access modifiers changed from: private */
    public Context ctx;
    private String daemonPath;
    private WindowManager.LayoutParams espParams;
    /* access modifiers changed from: private */
    public String expire = "DTEXPIRE";
    /* access modifiers changed from: private */
    public Service floater;
    Drawable icon;
    /* access modifiers changed from: private */
    public boolean isVisible = false;
    /* access modifiers changed from: private */
    public View mFloatingView;
    private FrameLayout mFrameLayout;
    /* access modifiers changed from: private */
    public WindowManager.LayoutParams mParams;
    /* access modifiers changed from: private */
    public WindowManager mWindowManager;
        public Prefs prefs;
    private Timer timer;
    /* access modifiers changed from: private */
    public final TrustManager[] trustAllCerts = {new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}

			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}

			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}
		}};

    private interface BTN {
        void OnWrite(boolean z);
    }

    private interface SBar {
        void OnWrite(int i);
    }

    /* renamed from: com.vip.loader.Loader$SW */
    private interface C0016SW {
        void OnWrite(boolean z);
    }

    public static native void AimbotStart();

     private native String Fechar();

    public static native String Icon();

    public static native int IconSize();

    /* access modifiers changed from: private */
    public native String OFF();

    /* access modifiers changed from: private */
    /* renamed from: ON */
    public native String m0ON();

    private native String PngBanner();

    /* access modifiers changed from: private */
    public native void ProgressSeekbar(int i, int i2);

    public static native void changeSeekBar(int i, int i2);

    public static native void changeToggle(int i);

    public static native int init();



	@Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }


	//When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        System.loadLibrary("hook");
         FloatButton();
         startServer();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
				public void run() {
					Thread();
					handler.postDelayed(this, 1000);
				}
			});
    }
	
    

    public static void deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            for (File child : directory.listFiles()) {
                deleteDirectory(child);
            }
        }
        directory.delete();
    }

    /* access modifiers changed from: private */
    public void Thread() {
        if (this.mFloatingView == null) {
            return;
        }
        if (isChayNgam()) {
            this.mFloatingView.setVisibility(4);
        } else {
            this.mFloatingView.setVisibility(0);
        }
    }

    private boolean isChayNgam() {
        ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
        if (Build.VERSION.SDK_INT >= 21) {
            ActivityManager.getMyMemoryState(runningAppProcessInfo);
        }
        return runningAppProcessInfo.importance != 100;
    }

    
    private void FloatButton() {
        this.mFrameLayout = new FrameLayout(this);
        this.mFrameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        RelativeLayout relativeLayout = new RelativeLayout(this);
        this.RelativeContainer = relativeLayout;
        relativeLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        RelativeLayout relativeLayout2 = new RelativeLayout(this);
        this.RelativeCollapsed = relativeLayout2;
        relativeLayout2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        this.RelativeCollapsed.setVisibility(0);
        this.RelativeCollapsed.setGravity(5);
        byte[] imageBytesLogo = Base64.decode(Icon(), 0);
        Bitmap LogoPng = BitmapFactory.decodeByteArray(imageBytesLogo, 0, imageBytesLogo.length);
        GradientDrawable BackgroundLogo = new GradientDrawable();
        BackgroundLogo.setShape(1);
        BackgroundLogo.setColor(Color.parseColor("#FF6600"));
        this.ImagemLogo = new ImageView(this);
        this.ImagemLogo.setLayoutParams(new LinearLayout.LayoutParams(m1dp(65), m1dp(65)));
        this.ImagemLogo.setScaleType(ImageView.ScaleType.FIT_XY);
        this.ImagemLogo.setImageBitmap(LogoPng);
        this.ImagemLogo.setPadding(m1dp(2), m1dp(2), m1dp(2), m1dp(2));
        this.ImagemLogo.setBackground(BackgroundLogo);
        GradientDrawable gradientDrawable = new GradientDrawable();
        this.BackgroundPrincipal = gradientDrawable;
        gradientDrawable.setShape(0);
        this.BackgroundPrincipal.setColor(-16777216);
        this.BackgroundPrincipal.setStroke(m1dp(2), Color.parseColor("#FF6600"));
        this.BackgroundPrincipal.setCornerRadius((float) m1dp(5));
        this.LayoutPrincipal = new LinearLayout(this);
        LinearLayout.LayoutParams principalParams = new LinearLayout.LayoutParams(m1dp(250), m1dp(280));
        this.LayoutPrincipal.setLayoutParams(principalParams);
        this.LayoutPrincipal.setVisibility(8);
        this.LayoutPrincipal.setOrientation(1);
        this.LayoutPrincipal.setBackground(this.BackgroundPrincipal);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        this.BackgroundBanner = gradientDrawable2;
        gradientDrawable2.setShape(0);
        this.BackgroundBanner.setColor(-16777216);
        this.BackgroundBanner.setStroke(m1dp(2), Color.parseColor("#FF6600"));
        setCornerRadius(this.BackgroundBanner, (float) m1dp(5), (float) m1dp(5), 0.0f, 0.0f);
        LinearLayout linearLayout = new LinearLayout(this);
        this.LayoutBanner = linearLayout;
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.LayoutBanner.setGravity(17);
        this.LayoutBanner.setOrientation(0);
        this.LayoutBanner.setBackground(this.BackgroundBanner);
        byte[] imageByteSBaranner = Base64.decode(PngBanner(), 0);
        Bitmap BannerPng = BitmapFactory.decodeByteArray(imageByteSBaranner, 0, imageByteSBaranner.length);
        this.ImagemBanner = new ImageView(this);
        LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(m1dp(150), m1dp(70));
        bannerParams.topMargin = m1dp(1);
        this.ImagemBanner.setLayoutParams(bannerParams);
        this.ImagemBanner.setScaleType(ImageView.ScaleType.FIT_XY);
         LinearLayout.LayoutParams layoutParams = principalParams;
        this.ImagemBanner.setPadding(m1dp(2), m1dp(2), m1dp(2), m1dp(2));
        this.ImagemBanner.setImageBitmap(BannerPng);
        this.ScrollFuncs = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, m1dp(151));
        this.ScrollFuncs.setLayoutParams(scrollParams);
        this.LayoutFuncs = new LinearLayout(this);
        LinearLayout.LayoutParams funcsParams = new LinearLayout.LayoutParams(-1, -1);
        this.LayoutFuncs.setLayoutParams(funcsParams);
        this.LayoutFuncs.setOrientation(1);
        this.LayoutClose = new LinearLayout(this);
        this.LayoutClose.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.LayoutClose.setOrientation(0);
        this.LayoutClose.setGravity(5);
        GradientDrawable gradientDrawable3 = new GradientDrawable();
        this.BackgroundFechar = gradientDrawable3;
        gradientDrawable3.setColor(0);
        this.BackgroundFechar.setStroke(m1dp(2), Color.parseColor("#bababa"));
        LinearLayout.LayoutParams layoutParams2 = scrollParams;
        LinearLayout.LayoutParams layoutParams3 = funcsParams;
        setCornerRadius(this.BackgroundFechar, (float) m1dp(5), (float) m1dp(5), (float) m1dp(5), (float) m1dp(20));
        this.ButtonFechar = new Button(this);
        LinearLayout.LayoutParams fecharParams = new LinearLayout.LayoutParams(m1dp(80), m1dp(35));
        fecharParams.rightMargin = m1dp(8);
        fecharParams.topMargin = m1dp(10);
        fecharParams.bottomMargin = m1dp(5);
        this.ButtonFechar.setLayoutParams(fecharParams);
        this.ButtonFechar.setText(Fechar());
        this.ButtonFechar.setTextColor(Color.parseColor("#FF6600"));
        this.ButtonFechar.setGravity(17);
        this.ButtonFechar.setAllCaps(false);
        this.ButtonFechar.setTypeface((Typeface) null, 1);
        this.ButtonFechar.setPadding(m1dp(8), m1dp(2), m1dp(2), m1dp(2));
        this.ButtonFechar.setBackground(this.BackgroundFechar);
        AddViews();
        this.mFloatingView = this.mFrameLayout;
        if (Build.VERSION.SDK_INT >= 26) {
            this.mParams = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            this.mParams = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        this.mParams.gravity = 8388659;
        this.mParams.x = 0;
        this.mParams.y = 100;
        WindowManager windowManager = (WindowManager) this.getSystemService("window");
        this.mWindowManager = windowManager;
        windowManager.addView(this.mFloatingView, this.mParams);
        View collapsedView = this.RelativeCollapsed;
        View expandedView = this.LayoutPrincipal;
         this.mFloatingView.setOnTouchListener(onTouchListener());
        this.ImagemLogo.setOnTouchListener(onTouchListener());
        initMenuButton(collapsedView, expandedView);
        
    }

    private void AddViews() {
        this.mFrameLayout.addView(this.RelativeContainer);
        this.RelativeContainer.addView(this.RelativeCollapsed);
        this.RelativeContainer.addView(this.LayoutPrincipal);
        this.RelativeCollapsed.addView(this.ImagemLogo);
        this.LayoutPrincipal.addView(this.LayoutBanner);
        this.LayoutBanner.addView(this.ImagemBanner);
        this.LayoutPrincipal.addView(this.ScrollFuncs);
        this.ScrollFuncs.addView(this.LayoutFuncs);
        addSpaceMenu(m1dp(2));
        this.LayoutPrincipal.addView(this.LayoutClose);
        this.LayoutClose.addView(this.ButtonFechar);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView;
            final View expandedView;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            {
                this.collapsedView = Loader.this.RelativeCollapsed;
                this.expandedView = Loader.this.LayoutPrincipal;
            }

            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                if (action == 0) {
                    this.initialX = Loader.this.mParams.x;
                    this.initialY = Loader.this.mParams.y;
                    this.initialTouchX = event.getRawX();
                    this.initialTouchY = event.getRawY();
                    return true;
                } else if (action == 1) {
                    int Xdiff = (int) (event.getRawX() - this.initialTouchX);
                    int Ydiff = (int) (event.getRawY() - this.initialTouchY);
                    if (Xdiff < 10 && Ydiff < 10 && Loader.this.isViewCollapsed()) {
                        this.collapsedView.setVisibility(8);
                        this.expandedView.setVisibility(0);
                    }
                    return true;
                } else if (action != 2) {
                    return false;
                } else {
                    Loader.this.mParams.x = this.initialX + ((int) (event.getRawX() - this.initialTouchX));
                    Loader.this.mParams.y = this.initialY + ((int) (event.getRawY() - this.initialTouchY));
                    Loader.this.mWindowManager.updateViewLayout(Loader.this.mFloatingView, Loader.this.mParams);
                    return true;
                }
            }
        };
    }

    private void initMenuButton(final View collapsedView, final View expandedView) {
        this.ImagemLogo.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					collapsedView.setVisibility(8);
					expandedView.setVisibility(0);
				}
			});
        this.ButtonFechar.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					collapsedView.setVisibility(0);
					expandedView.setVisibility(8);
				}
			});
        this.ButtonFechar.setOnLongClickListener(new View.OnLongClickListener() {
				public boolean onLongClick(View v) {
					if (!Loader.this.isVisible) {
						boolean unused = Loader.this.isVisible = true;
						Loader.this.RelativeCollapsed.setAlpha(0.0f);
						collapsedView.setVisibility(0);
						expandedView.setVisibility(8);
						Toast.makeText(Loader.this, "Menu invisivel!", 0).show();
					} else {
						boolean unused2 = Loader.this.isVisible = false;
						Loader.this.RelativeCollapsed.setAlpha(1.0f);
						collapsedView.setVisibility(0);
						expandedView.setVisibility(8);
						Toast.makeText(Loader.this, "Menu visivel!", 0).show();
					}
					return false;
				}
			});
    }

    
    public static String capitalize(String str) {
        if (str == null) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    /* access modifiers changed from: private */
    public void startServer() {
        Thread thread = new Thread() {
            public void run() {
                while (true) {
                    try {
                        Loader.AimbotStart();
                        Thread.sleep(10000);
                    } catch (Exception e) {
                        System.exit(0);
                    }
                }
            }
        };
        thread.setPriority(10);
        thread.start();
        modMenu();
    }
	
    private void modMenu() {
        addCategory("LK TEAM LAYOUT", Color.parseColor("#FFFFFF"), Color.parseColor("#FF6600"));
        
    }

    public void addButton(String texto, BTN listener) {
        GradientDrawable fundBtn = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.parseColor("#000000"), Color.parseColor("#000000")});
        fundBtn.setShape(0);
        fundBtn.setAlpha(230);
        fundBtn.setGradientType(0);
        fundBtn.setCornerRadius(8.0f);
        GradientDrawable OFF = new GradientDrawable();
        OFF.setShape(0);
        OFF.setColor(0);
        OFF.setCornerRadius(8.0f);
        Button btn = new Button(this);
        btn.setText(texto + " [OFF]");
        btn.setTextColor(-1);
        btn.setTextSize(10.0f);
        btn.setAllCaps(false);
        btn.setBackground(OFF);
        LinearLayout.LayoutParams params_btns = new LinearLayout.LayoutParams(-1, 60);
        btn.setPadding(3, 3, 3, 3);
        params_btns.bottomMargin = 5;
        btn.setLayoutParams(params_btns);
        final BTN btn2 = listener;
        final Button button = btn;
        final GradientDrawable gradientDrawable = fundBtn;
        final String str = texto;
        final GradientDrawable gradientDrawable2 = OFF;
        btn.setOnClickListener(new View.OnClickListener() {
				private boolean isActive = true;

				public void onClick(View v) {
					btn2.OnWrite(this.isActive);
					if (this.isActive) {
						button.setBackground(gradientDrawable);
					button.setText(str + Loader.this.m0ON());
						this.isActive = false;
						return;
					}
					this.isActive = true;
					button.setBackground(gradientDrawable2);
					Button button2 = button;
					button2.setText(str + Loader.this.OFF());
				}
			});
        this.LayoutFuncs.addView(btn);
    }

    /* access modifiers changed from: private */
    public boolean isViewCollapsed() {
        return this.mFloatingView == null || this.RelativeCollapsed.getVisibility() == 0;
    }

    private void addCategory(String text, int colorText, int colorBackground) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, m1dp(20));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(colorBackground);
        linearLayout.setGravity(17);
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(17);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, m1dp(20)));
        textView.setTextColor(colorText);
        textView.setTextSize(10.0f);
        linearLayout.addView(textView);
        this.LayoutFuncs.addView(linearLayout);
    }

    private void addSwitch(String name, final C0016SW listner) {
        Switch sw = new Switch(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.leftMargin = m1dp(5);
        layoutParams.rightMargin = m1dp(6);
        layoutParams.topMargin = m1dp(5);
        layoutParams.bottomMargin = m1dp(5);
        sw.setText(name);
        sw.setTextColor(-1);
        sw.setLayoutParams(layoutParams);
        sw.setTextSize(2, 15.0f);
        final GradientDrawable BackgroundCaixa = new GradientDrawable();
        BackgroundCaixa.setShape(0);
        BackgroundCaixa.setColor(-1);
        BackgroundCaixa.setCornerRadius((float) m1dp(10));
        BackgroundCaixa.setSize(m1dp(20), m1dp(20));
        BackgroundCaixa.setStroke(m1dp(1), -7829368);
        final GradientDrawable BackgrounSwitch = new GradientDrawable();
        BackgrounSwitch.setShape(0);
        BackgrounSwitch.setColor(-1);
        BackgrounSwitch.setStroke(m1dp(1), -7829368);
        BackgrounSwitch.setCornerRadius((float) m1dp(10));
        BackgrounSwitch.setSize(m1dp(20), m1dp(20));
        sw.setTrackDrawable(BackgroundCaixa);
        sw.setThumbDrawable(BackgrounSwitch);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					listner.OnWrite(isChecked);
					if (isChecked) {
						BackgrounSwitch.setStroke(Loader.this.m1dp(1), Color.parseColor("#FF6600"));
						BackgroundCaixa.setStroke(Loader.this.m1dp(1), Color.parseColor("#FF6600"));
						BackgroundCaixa.setColor(Color.parseColor("#FF6600"));
						return;
					}
					BackgrounSwitch.setStroke(Loader.this.m1dp(1), -7829368);
					BackgroundCaixa.setStroke(Loader.this.m1dp(1), -7829368);
					BackgroundCaixa.setColor(-1);
				}
			});
        this.LayoutFuncs.addView(sw);
        addSpace(m1dp(1));
    }
	

    private SeekBar addSeekBar(int max, final SBar listener) {
        final GradientDrawable Background_seek = new GradientDrawable();
        Background_seek.setShape(0);
        Background_seek.setColor(-1);
        Background_seek.setStroke(m1dp(1), -7829368);
        Background_seek.setCornerRadius((float) m1dp(10));
        Background_seek.setSize(m1dp(20), m1dp(20));
        final SeekBar SBar2 = new SeekBar(this);
        LinearLayout.LayoutParams SBarParams = new LinearLayout.LayoutParams(-1, m1dp(20));
        SBarParams.leftMargin = m1dp(5);
        SBarParams.rightMargin = m1dp(5);
        SBarParams.bottomMargin = m1dp(5);
        SBar2.setLayoutParams(SBarParams);
        SBar2.setMax(max);
        SBar2.setThumb(Background_seek);
        SBar2.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);
        SBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					listener.OnWrite(progress);
					if (progress > 0) {
						Background_seek.setColor(-1);
						Background_seek.setStroke(Loader.this.m1dp(1), Color.parseColor("#FF6600"));
						SBar2.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);
						return;
					}
					Background_seek.setColor(-1);
					Background_seek.setStroke(Loader.this.m1dp(1), -7829368);
					SBar2.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);
				}

				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});
        this.LayoutFuncs.addView(SBar2);
        addSpace(m1dp(1));
        return SBar2;
    }

    public void addBtnRemove(String text, View.OnClickListener onClickListener) {
        GradientDrawable backgroundBtn = new GradientDrawable();
        backgroundBtn.setColor(0);
        backgroundBtn.setStroke(m1dp(1), Color.parseColor("#e9ecef"));
        backgroundBtn.setCornerRadius((float) m1dp(4));
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams params_linearLayout = new LinearLayout.LayoutParams(-1, m1dp(30));
        params_linearLayout.leftMargin = m1dp(5);
        params_linearLayout.rightMargin = m1dp(5);
        params_linearLayout.topMargin = m1dp(5);
        params_linearLayout.bottomMargin = m1dp(5);
        linearLayout.setLayoutParams(params_linearLayout);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(17);
        Button btnSave = new Button(this);
        btnSave.setText(text);
        LinearLayout.LayoutParams params_btns = new LinearLayout.LayoutParams(-1, m1dp(30));
        params_btns.leftMargin = m1dp(5);
        params_btns.rightMargin = m1dp(5);
        btnSave.setPadding(m1dp(5), 0, m1dp(5), 0);
        btnSave.setLayoutParams(params_btns);
        btnSave.setGravity(17);
        btnSave.setBackground(backgroundBtn);
        btnSave.setTextSize(2, 12.0f);
        btnSave.setTextColor(Color.parseColor("#8A000000"));
        btnSave.setAllCaps(false);
        btnSave.setOnClickListener(onClickListener);
        linearLayout.addView(btnSave);
        this.LayoutFuncs.addView(linearLayout);
        addSpace(m1dp(1));
    }

    /* access modifiers changed from: private */
    public TextView addText(String def) {
        TextView tv = new TextView(this);
        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(-1, -2);
        tvParams.leftMargin = m1dp(5);
        tvParams.rightMargin = m1dp(5);
        tvParams.topMargin = m1dp(5);
        tv.setLayoutParams(tvParams);
        tv.setText(def);
        tv.setTextColor(-1);
        tv.setTextSize(2, 15.0f);
        this.LayoutFuncs.addView(tv);
        return tv;
    }

    private void addSpace(int space) {
        View separator = new View(this);
        LinearLayout.LayoutParams params = setParams();
        params.height = space;
        separator.setLayoutParams(params);
        separator.setBackgroundColor(Color.parseColor("#FF6600"));
        this.LayoutFuncs.addView(separator);
    }

    private void addSpaceMenu(int space) {
        View separator = new View(this);
        LinearLayout.LayoutParams params = setParams();
        params.height = space;
        separator.setLayoutParams(params);
        separator.setBackgroundColor(Color.parseColor("#FF6600"));
        this.LayoutPrincipal.addView(separator);
    }

    private LinearLayout.LayoutParams setParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -1);
        params.gravity = 16;
        return params;
    }

    private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }

    public String getUniqueId(Context ctx2) {
        return UUID.nameUUIDFromBytes((getDeviceName() + Settings.Secure.getString(ctx2.getContentResolver(), "android_id") + Build.HARDWARE).replace(" ", "").getBytes()).toString().replace("-", "");
    }

    private String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return model;
        }
        return manufacturer + " " + model;
    }

    private boolean isTablet() {
        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        float yInches = ((float) metrics.heightPixels) / metrics.ydpi;
        float xInches = ((float) metrics.widthPixels) / metrics.xdpi;
        return Math.sqrt((double) ((xInches * xInches) + (yInches * yInches))) >= 6.5d;
    }

    private float getBestTextSize() {
        float d = TypedValue.applyDimension(1, 8.0f, this.getResources().getDisplayMetrics());
        if (isTablet()) {
            d += 7.0f;
        }
        if (d <= 20.0f || isTablet()) {
            return d;
        }
        return 20.0f;
    }

    /* access modifiers changed from: private */
    /* renamed from: dp */
    public int m1dp(int paramInt) {
        return (int) TypedValue.applyDimension(1, (float) paramInt, this.getResources().getDisplayMetrics());
    }

    private int dp2px(int paramInt) {
        return (int) ((((float) paramInt) * this.getResources().getDisplayMetrics().density) + 0.5f);
    }

    private void setCornerRadius(GradientDrawable gradientDrawable, float f) {
        gradientDrawable.setCornerRadius(f);
    }

    private static void setCornerRadius(GradientDrawable gradientDrawable, float f, float f2, float f3, float f4) {
        gradientDrawable.setCornerRadii(new float[]{f, f, f2, f2, f3, f3, f4, f4});
    }
}

