package com.vip.loader;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Set;

public class Prefs {
    private static final boolean DEFAULT_BOOLEAN_VALUE = false;
    private static final double DEFAULT_DOUBLE_VALUE = -1.0d;
    private static final float DEFAULT_FLOAT_VALUE = -1.0f;
    private static final int DEFAULT_INT_VALUE = -1;
    private static final long DEFAULT_LONG_VALUE = -1;
    private static final String DEFAULT_STRING_VALUE = "";
    private static final String LENGTH = "_length";
    private static Prefs prefsInstance;
    private SharedPreferences sharedPreferences;

    private Prefs(Context context) {
        Context applicationContext = context.getApplicationContext();
        this.sharedPreferences = applicationContext.getSharedPreferences(context.getPackageName() + "_preferences", 0);
    }

    private Prefs(Context context, String preferencesName) {
        this.sharedPreferences = context.getApplicationContext().getSharedPreferences(preferencesName, 0);
    }

    public static Prefs with(Context context) {
        if (prefsInstance == null) {
            prefsInstance = new Prefs(context);
        }
        return prefsInstance;
    }

    public static Prefs with(Context context, boolean forceInstantiation) {
        if (forceInstantiation) {
            prefsInstance = new Prefs(context);
        }
        return prefsInstance;
    }

    public static Prefs with(Context context, String preferencesName) {
        if (prefsInstance == null) {
            prefsInstance = new Prefs(context, preferencesName);
        }
        return prefsInstance;
    }

    public static Prefs with(Context context, String preferencesName, boolean forceInstantiation) {
        if (forceInstantiation) {
            prefsInstance = new Prefs(context, preferencesName);
        }
        return prefsInstance;
    }

    public String read(String what) {
        return this.sharedPreferences.getString(what, "");
    }

    public String read(String what, String defaultString) {
        return this.sharedPreferences.getString(what, defaultString);
    }

    public void write(String where, String what) {
        this.sharedPreferences.edit().putString(where, what).apply();
    }

    public int readInt(String what) {
        return this.sharedPreferences.getInt(what, DEFAULT_INT_VALUE);
    }

    public int readInt(String what, int defaultInt) {
        return this.sharedPreferences.getInt(what, defaultInt);
    }

    public void writeInt(String where, int what) {
        this.sharedPreferences.edit().putInt(where, what).apply();
    }

    public double readDouble(String what) {
        if (!contains(what)) {
            return DEFAULT_DOUBLE_VALUE;
        }
        return Double.longBitsToDouble(readLong(what));
    }

    public double readDouble(String what, double defaultDouble) {
        if (!contains(what)) {
            return defaultDouble;
        }
        return Double.longBitsToDouble(readLong(what));
    }

    public void writeDouble(String where, double what) {
        writeLong(where, Double.doubleToRawLongBits(what));
    }

    public float readFloat(String what) {
        return this.sharedPreferences.getFloat(what, DEFAULT_FLOAT_VALUE);
    }

    public float readFloat(String what, float defaultFloat) {
        return this.sharedPreferences.getFloat(what, defaultFloat);
    }

    public void writeFloat(String where, float what) {
        this.sharedPreferences.edit().putFloat(where, what).apply();
    }

    public long readLong(String what) {
        return this.sharedPreferences.getLong(what, DEFAULT_LONG_VALUE);
    }

    public long readLong(String what, long defaultLong) {
        return this.sharedPreferences.getLong(what, defaultLong);
    }

    public void writeLong(String where, long what) {
        this.sharedPreferences.edit().putLong(where, what).apply();
    }

    public boolean readBoolean(String what) {
        return readBoolean(what, false);
    }

    public boolean readBoolean(String what, boolean defaultBoolean) {
        return this.sharedPreferences.getBoolean(what, defaultBoolean);
    }

    public void writeBoolean(String where, boolean what) {
        this.sharedPreferences.edit().putBoolean(where, what).apply();
    }

    public void putStringSet(String key, Set<String> value) {
        this.sharedPreferences.edit().putStringSet(key, value).apply();
    }

    public Set<String> getStringSet(String key, Set<String> defValue) {
        return this.sharedPreferences.getStringSet(key, defValue);
    }

    public void remove(String key) {
        if (contains(key + LENGTH)) {
            int stringSetLength = readInt(key + LENGTH);
            if (stringSetLength >= 0) {
                SharedPreferences.Editor edit = this.sharedPreferences.edit();
                edit.remove(key + LENGTH).apply();
                for (int i = 0; i < stringSetLength; i++) {
                    SharedPreferences.Editor edit2 = this.sharedPreferences.edit();
                    edit2.remove(key + "[" + i + "]").apply();
                }
            }
        }
        this.sharedPreferences.edit().remove(key).apply();
    }

    public boolean contains(String key) {
        return this.sharedPreferences.contains(key);
    }

    public void clear() {
        this.sharedPreferences.edit().clear().apply();
    }
}
